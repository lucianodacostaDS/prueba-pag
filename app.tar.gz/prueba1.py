num1= int(input("Introduzca un numero"))
num2= int(input("Introduzca otro numero"))

print(num1+num2)