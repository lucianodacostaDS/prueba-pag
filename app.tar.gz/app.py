import flet as ft

def main(page: ft.Page):
    page.title = "Mi Primera App"
    
    # Inputs
    num1 = ft.TextField(label="Introduzca un numero", keyboard_type=ft.KeyboardType.NUMBER)
    num2 = ft.TextField(label="Introduzca otro numero", keyboard_type=ft.KeyboardType.NUMBER)
    
    # Output
    resultado = ft.Text(value="", size=24, weight=ft.FontWeight.BOLD)

    def sumar(e):
        try:
            valor1 = int(num1.value)
            valor2 = int(num2.value)
            resultado.value = f"Resultado: {valor1 + valor2}"
        except ValueError:
            resultado.value = "Error: Introduce solo números"
        page.update() # Refresca la pantalla para mostrar el resultado

    # Agregar todo a la página
    page.add(
        num1,
        num2,
        ft.Button("Sumar", on_click=sumar),
        resultado
    )

ft.run(main)